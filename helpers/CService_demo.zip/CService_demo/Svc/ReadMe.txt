========================================================================
    APPLICAZIONE CONSOLE: cenni preliminari sul progetto Svc
========================================================================

La creazione guidata applicazione ha creato questa applicazione Svc.  

Questo file contiene un riepilogo del contenuto di ciascun file che fa parte
dell'applicazione Svc.


Svc.vcproj
    File di progetto principale per i progetti VC++ generati tramite una creazione guidata applicazione. 
    Contiene informazioni sulla versione di Visual C++ che ha generato il file e 
    informazioni sulle piattaforme, le configurazioni e le caratteristiche del 
    progetto selezionate con la creazione guidata applicazione.

Svc.cpp
    File di origine principale dell'applicazione.

/////////////////////////////////////////////////////////////////////////////
Altri file standard:

StdAfx.h, StdAfx.cpp
    Tali file vengono utilizzati per generare il file di intestazione
    precompilato Svc.pch e il file dei tipi precompilato .obj.

/////////////////////////////////////////////////////////////////////////////
Altre note:

la creazione guidata applicazione utilizza i commenti "TODO:" per indicare le parti del
 codice sorgente da aggiungere o personalizzare.

/////////////////////////////////////////////////////////////////////////////
